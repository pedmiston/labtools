#! /usr/bin/env python
import trials_functions_tests
import generator_functions_tests
