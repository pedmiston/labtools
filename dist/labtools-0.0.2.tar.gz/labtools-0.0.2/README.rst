Resources for Behavioral Experiments in Python
==============================================

This package contains various helper functions and classes for conducting behavioral research experiments in python.
