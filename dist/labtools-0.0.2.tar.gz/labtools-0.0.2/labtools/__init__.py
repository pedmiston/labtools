#!/usr/bin/env python
"""
.. module:: resources
    :synopsis: Helper functions for behavioral research
.. moduleauthor:: Pierce Edmiston <pierce.edmiston@gmail.com>
"""

from trials_functions import *
from generator_functions import *
